﻿using System;
using System.Collections.Generic;

namespace csillagkep.Models
{
    public partial class ConstellationLine
    {
        public int Star1 { get; set; }
        public int Star2 { get; set; }
    }
}
